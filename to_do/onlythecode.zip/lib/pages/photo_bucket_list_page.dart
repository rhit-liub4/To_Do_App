import 'dart:async';

import 'package:firebase_ui_firestore/firebase_ui_firestore.dart';
import 'package:flutter/material.dart';
import 'package:photo_bucket/pages/photo_bucket_detail_page.dart';


import '../components/list_page_side_drawer.dart';
import '../components/photo_bucket_row_component.dart';
import '../managers/auth_manager.dart';
import '../managers/photo_bucket_collection_manager.dart';
import '../models/photo_bucket.dart';
import 'login_front_page.dart';

class PhotoBucketListPage extends StatefulWidget {
  const PhotoBucketListPage({super.key});

  @override
  State<PhotoBucketListPage> createState() => _PhotoBucketListPageState();
}

class _PhotoBucketListPageState extends State<PhotoBucketListPage> {
  final urlTextController = TextEditingController();
  final captionTextController = TextEditingController();

  bool _isShowingAllPhotos = true;

  UniqueKey? _loginObserverKey;
  UniqueKey? _logoutObserverKey;

  @override
  void initState() {
    super.initState();

    _showAllPhotos();

    _loginObserverKey = AuthManager.instance.addLoginObserver(() {
      setState(() {});
    });

    _logoutObserverKey = AuthManager.instance.addLogoutObserver(() {
      _showAllPhotos();
      setState(() {});
    });
  }

  void _showAllPhotos() {
    setState(() {
      _isShowingAllPhotos = true;
    });
  }

  void _showOnlyMyPhotos() {
    setState(() {
      _isShowingAllPhotos = false;
    });
  }

  @override
  void dispose() {
    urlTextController.dispose();
    captionTextController.dispose();
    AuthManager.instance.removeObserver(_loginObserverKey);
    AuthManager.instance.removeObserver(_logoutObserverKey);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Photo Bucket"),
        actions: AuthManager.instance.isSignedIn
            ? null
            : [
          IconButton(
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (BuildContext context) {
                  return const LoginFrontPage();
                },
              ));
            },
            tooltip: "Log in",
            icon: const Icon(Icons.login),
          ),
        ],
      ),
      backgroundColor: Colors.grey[100],
      body: FirestoreListView<PhotoBucket>(
        query: _isShowingAllPhotos
            ? PhotoBucketCollectionManager.instance.allPhotosQuery
            : PhotoBucketCollectionManager.instance.mineOnlyPhotoBucketQuery,
        itemBuilder: (context, snapshot) {
          PhotoBucket mq = snapshot.data();
          return PhotoBucketRow(
            photoBucket: mq,
            onTap: () async {
              print("You clicked on the photo ${mq.url} - ${mq.caption}");
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (BuildContext context) {
                    return PhotoBucketDetailPage(
                        mq.documentId!); // In Firebase use a documentId
                  },
                ),
              );
              setState(() {});
            },
          );
        },
      ),
      drawer: AuthManager.instance.isSignedIn
          ? ListPageSideDrawer(
        showAllCallback: () {
          print("PhotoBucketListPage: Callback to Show all photos");
          _showAllPhotos();
        },
        showOnlyMineCallback: () {
          print("PhotoBucketListPage: Callback to Show only my photos");
          _showOnlyMyPhotos();
        },
      )
          : null,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          if (AuthManager.instance.isSignedIn) {
            showCreatePhotoCaption(context);
          } else {
            showMustLogInDialog(context);
          }
        },
        tooltip: 'Create',
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<void> showCreatePhotoCaption(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Create a Photo'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4.0),
                child: TextFormField(
                  controller: urlTextController,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Enter the URL',
                  ),
                ),
              ),
              Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 4.0),
                child: TextFormField(
                  controller: captionTextController,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Enter the caption',
                  ),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Create'),
              onPressed: () {
                setState(() {
                  PhotoBucketCollectionManager.instance.add(
                    url: urlTextController.text,
                    caption: captionTextController.text,
                  );
                  urlTextController.text = "";
                  captionTextController.text = "";
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> showMustLogInDialog(BuildContext context) {
    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text("Login Required"),
          content: const Text(
              "You must be signed in to post.  Would you like to sign in now?"),
          actions: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text("Go sign in"),
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.push(context, MaterialPageRoute(
                  builder: (BuildContext context) {
                    return const LoginFrontPage();
                  },
                ));
              },
            ),
          ],
        );
      },
    );
  }
}
