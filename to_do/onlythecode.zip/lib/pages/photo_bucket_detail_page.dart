import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

import '../managers/auth_manager.dart';
import '../managers/photo_bucket_collection_manager.dart';
import '../managers/photo_bucket_document_manager.dart';

class PhotoBucketDetailPage extends StatefulWidget {
  final String documentId;
  const PhotoBucketDetailPage(this.documentId, {super.key});

  @override
  State<PhotoBucketDetailPage> createState() => _PhotoBucketDetailPageState();
}

class _PhotoBucketDetailPageState extends State<PhotoBucketDetailPage> {
  final urlTextController = TextEditingController();
  final captionTextController = TextEditingController();

  StreamSubscription? photoBucketSubscription;

  @override
  void initState() {
    super.initState();

    photoBucketSubscription =
        PhotoBucketDocumentManager.instance.startListening(
      widget.documentId,
      () {
        setState(() {});
      },
    );
  }

  @override
  void dispose() {
    urlTextController.dispose();
    captionTextController.dispose();
    PhotoBucketDocumentManager.instance.stopListening(photoBucketSubscription);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool showEditDelete =
        PhotoBucketDocumentManager.instance.latestPhotoBucket != null &&
            AuthManager.instance.uid.isNotEmpty &&
            AuthManager.instance.uid ==
                PhotoBucketDocumentManager
                    .instance.latestPhotoBucket!.authorUid;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Photo Bucket"),
        actions: [
          Visibility(
            visible: showEditDelete,
            child: IconButton(
              onPressed: () {
                showEditPhotoDialog(context);
              },
              icon: const Icon(Icons.edit),
            ),
          ),
          Visibility(
            visible: showEditDelete,
            child: IconButton(
              onPressed: () {
                final justDeletedUrl =
                    PhotoBucketDocumentManager.instance.latestPhotoBucket!.url;
                final justDeletedCaption = PhotoBucketDocumentManager
                    .instance.latestPhotoBucket!.caption;

                PhotoBucketDocumentManager.instance.delete();

                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: const Text('Photo Deleted'),
                    action: SnackBarAction(
                      label: 'Undo',
                      onPressed: () {
                        PhotoBucketCollectionManager.instance.add(
                          url: justDeletedUrl,
                          caption: justDeletedCaption,
                        );
                      },
                    ),
                  ),
                );
                Navigator.pop(context);
              },
              icon: const Icon(Icons.delete),
            ),
          ),
          // const SizedBox(
          //   width: 40.0,
          // ),
        ],
      ),
      backgroundColor: Colors.grey[100],
      body: Container(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            LabelledTextDisplay(
              title: "Caption:",
              content: PhotoBucketDocumentManager
                      .instance.latestPhotoBucket?.caption ??
                  "",
              iconData: Icons.format_quote,
            ),
            Container(
              constraints: const BoxConstraints(maxHeight: 600.0, maxWidth: 600.0),
              child: CachedNetworkImage(
                imageUrl: PhotoBucketDocumentManager.instance.latestPhotoBucket?.url ?? "",
                progressIndicatorBuilder: (context, url, downloadProgress) =>
                    CircularProgressIndicator(value: downloadProgress.progress),
                errorWidget: (context, url, error) => Icon(Icons.error),
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<void> showEditPhotoDialog(BuildContext context) {
    urlTextController.text =
        PhotoBucketDocumentManager.instance.latestPhotoBucket?.url ?? "";
    captionTextController.text =
        PhotoBucketDocumentManager.instance.latestPhotoBucket?.caption ?? "";

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Edit this Photo'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4.0),
                child: TextFormField(
                  controller: urlTextController,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Url:',
                  ),
                ),
              ),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4.0),
                child: TextFormField(
                  controller: captionTextController,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Caption:',
                  ),
                ),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: TextButton.styleFrom(
                textStyle: Theme.of(context).textTheme.labelLarge,
              ),
              child: const Text('Update'),
              onPressed: () {
                setState(() {
                  PhotoBucketDocumentManager.instance.update(
                    url: urlTextController.text,
                    caption: captionTextController.text,
                  );
                  urlTextController.text = "";
                  captionTextController.text = "";
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }
}

class LabelledTextDisplay extends StatelessWidget {
  final String title;
  final String content;
  final IconData iconData;

  const LabelledTextDisplay({
    super.key,
    required this.title,
    required this.content,
    required this.iconData,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(
                fontSize: 30.0,
                fontWeight: FontWeight.w800,
                fontFamily: "Caveat"),
          ),
          Card(
            child: Container(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  Icon(iconData),
                  const SizedBox(
                    width: 8.0,
                  ),
                  Flexible(
                    child: Text(
                      content,
                      style: const TextStyle(
                        fontSize: 18.0,
                        // fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
