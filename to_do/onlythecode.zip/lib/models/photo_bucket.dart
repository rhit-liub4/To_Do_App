import 'package:cloud_firestore/cloud_firestore.dart';

import 'firestore_model_utils.dart';


const String kPhotoBucketCollectionPath = "Pictures";
const String kPhotoBucket_authorUid = "authorUid";
const String kPhotoBucket_lastTouched = "lastTouched";
const String kPhotoBucket_caption = "caption";
const String kPhotoBucket_url = "url";

class PhotoBucket {
  String? documentId;
  String authorUid;
  Timestamp lastTouched;
  String caption;
  String url;

  PhotoBucket({
    this.documentId,
    required this.authorUid,
    required this.url,
    required this.caption,
    required this.lastTouched,
  });

  PhotoBucket.from(DocumentSnapshot doc)
      : this(
    documentId: doc.id,
    authorUid:
    FirestoreModelUtils.getStringField(doc, kPhotoBucket_authorUid),
    lastTouched: FirestoreModelUtils.getTimestampField(
        doc, kPhotoBucket_lastTouched),
    caption: FirestoreModelUtils.getStringField(doc, kPhotoBucket_caption),
    url: FirestoreModelUtils.getStringField(doc, kPhotoBucket_url),
  );

  Map<String, Object?> toMap() {
    return {
      kPhotoBucket_authorUid: authorUid,
      kPhotoBucket_lastTouched: lastTouched,
      kPhotoBucket_caption: caption,
      kPhotoBucket_url: url,
    };
  }

  @override
  String toString() {
    return "$url from the photo $caption";
  }
}