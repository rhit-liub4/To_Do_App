import 'package:flutter/material.dart';

import '../models/photo_bucket.dart';


class PhotoBucketRow extends StatelessWidget {
  final PhotoBucket photoBucket;
  final Function() onTap;

  const PhotoBucketRow({
    required this.photoBucket,
    required this.onTap,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 1.0),
        child: Card(
          child: ListTile(
            leading: const Icon(Icons.photo),
            trailing: const Icon(Icons.chevron_right),
            title: Text(
              photoBucket.caption,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ),
    );
  }
}
