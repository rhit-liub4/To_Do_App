import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/photo_bucket.dart';


class PhotoBucketDocumentManager {
  PhotoBucket? latestPhotoBucket;
  final CollectionReference _ref;

  static final PhotoBucketDocumentManager instance =
  PhotoBucketDocumentManager._privateConstructor();

  PhotoBucketDocumentManager._privateConstructor()
      : _ref = FirebaseFirestore.instance.collection(kPhotoBucketCollectionPath);

  StreamSubscription startListening(String documentId, Function() observer) {
    return _ref
        .doc(documentId)
        .snapshots()
        .listen((DocumentSnapshot docSnapshot) {
      latestPhotoBucket = PhotoBucket.from(docSnapshot);
      observer();
    });
  }

  void stopListening(StreamSubscription? subscription) =>
      subscription?.cancel();

  void update({
    required String url,
    required String caption,
  }) {
    if (latestPhotoBucket == null) {
      return;
    }
    _ref.doc(latestPhotoBucket!.documentId!).update({
      kPhotoBucket_url: url,
      kPhotoBucket_caption: caption,
      kPhotoBucket_lastTouched: Timestamp.now(),
    }).catchError((error) => print("Failed to update the photo: $error"));
  }

  Future<void> delete() {
    return _ref.doc(latestPhotoBucket?.documentId!).delete();
  }
}
