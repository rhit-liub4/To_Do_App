import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/photo_bucket.dart';
import 'auth_manager.dart';


class PhotoBucketCollectionManager {
  List<PhotoBucket> latestPhotos = [];
  final CollectionReference _ref;

  static final PhotoBucketCollectionManager instance =
  PhotoBucketCollectionManager._privateConstructor();

  PhotoBucketCollectionManager._privateConstructor()
      : _ref = FirebaseFirestore.instance.collection(kPhotoBucketCollectionPath);


  StreamSubscription startListening(Function() observer,
      {bool isFilteredForMine = false}) {
    Query query = _ref.orderBy(kPhotoBucket_lastTouched, descending: true);
    if (isFilteredForMine) {
      query = query.where(kPhotoBucket_authorUid,
          isEqualTo: AuthManager.instance.uid);
    }
    return query.snapshots().listen((QuerySnapshot querySnapshot) {
      latestPhotos =
          querySnapshot.docs.map((doc) => PhotoBucket.from(doc)).toList();
      observer();
       //print(latestPhotos);
    });
  }

  void stopListening(StreamSubscription? subscription) {
    subscription?.cancel();
  }

  Future<void> add({

    required String url,
    required String caption,
  }) {


    return _ref
        .add({
      kPhotoBucket_authorUid: AuthManager.instance.uid,
      kPhotoBucket_url: url,
      kPhotoBucket_caption: caption,
      kPhotoBucket_lastTouched: Timestamp.now(),
    })
        .then((DocumentReference docRef) =>
        print("Photo added with id ${docRef.id}"))
        .catchError((error) => print("Failed to add photo: $error"));
  }

  // Firebase UI Firestore stuff

  Query<PhotoBucket> get allPhotosQuery => _ref
      .orderBy(kPhotoBucket_lastTouched, descending: true)
      .withConverter<PhotoBucket>(
    fromFirestore: (snapshot, _) => PhotoBucket.from(snapshot),
    toFirestore: (mq, _) => mq.toMap(),
  );

  Query<PhotoBucket> get mineOnlyPhotoBucketQuery => allPhotosQuery
      .where(kPhotoBucket_authorUid, isEqualTo: AuthManager.instance.uid);
}
